import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  selected = 'option2';

  favoriteFood = "pho";

  constructor(private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
  }

  saveChanges($event){

    console.log("event",$event);
  }

  openGallery(){
    this.router.navigate(['user-gallery']).then(nav => {
      console.log(nav); // true if navigation is successful
    }, err => {
      console.log(err) // when there's an error
    });
  }

}

import { BrowserModule } from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChatService } from './services/chat.service';
import { FormsModule ,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import {MatListModule} from '@angular/material/list';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import { InboxPageComponent } from '../app/inbox-page/inbox-page.component';
import {MatDividerModule} from '@angular/material/divider';
import { LoginComponent } from '../app/login/login.component';
import { RegisterComponent} from '../app/register/register.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProfileComponent } from '../app/profile/profile.component';
import { UserGalleryComponent } from '../app/user-gallery/user-gallery.component';
import { FileSelectDirective } from 'ng2-file-upload';

const config: SocketIoConfig = { url: 'http://localhost:4444', options: {} };

@NgModule({
  declarations: [
    AppComponent,InboxPageComponent,LoginComponent, RegisterComponent,ProfileComponent,UserGalleryComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule, HttpClientModule,MatSliderModule,MatListModule,MatSelectModule,
    MatInputModule,MatFormFieldModule,MatIconModule,MatDividerModule,NgbModule,
    AppRoutingModule,SocketIoModule.forRoot(config), BrowserAnimationsModule
  ],
  providers: [ChatService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }

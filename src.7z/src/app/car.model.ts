

export class Car {
  
    public id: string;
  public brand: 'BMW' | 'Audi' | 'Lamborghini' | 'Mercedes';
  public model: string;
  public year: number;
  public price:number;
  public desc: string;
  public base64Img: string;

  deserialize(input: any): this {
    return Object.assign(this, input);
  }
  
 
}


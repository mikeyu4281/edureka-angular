export class ImageModel {
  
    public imgSource: string;
    public user: string;
    
  }
  
  
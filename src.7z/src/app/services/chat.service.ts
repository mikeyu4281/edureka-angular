import * as io from 'socket.io-client';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { stringify } from 'querystring';
import { Time } from '@angular/common';

//"chatId":81,"sender":"Name1","recipient":"name2","sender_message":"hello","rec_message":"time","datetimechat":"2020-01-08T15:38:14.000Z"}
export interface ChatMessage {
    chatId: string;
    sender: number;
    recipient: number;
    sender_message: string;
    rec_message: string;
    time: string;

}

@Injectable()
export class ChatService {
    private url = 'http://localhost:5000';
    private socket;
    totalAngularPackages;
    message: string;
    http: HttpClient;
    constructor(http: HttpClient) {
        this.http = http;
        //   this.socket = io(this.url);
    }

    selectedUser: string;

    public sendMessage(user, message) {
        // message.content = message;
        //sender,recipient,sender_message,rec_message,datetimechat
        user = "Name1";
        this.selectedUser = "name2";
        this.http.post<any>('http://localhost:5000/event', { sender: user, recipient: this.selectedUser, message: this.message }).subscribe(data => {
            this.message = data.id;
            console.log("Message sent");
        })
        //     this.socket.emit('new-message', user, message);

        let payload = {
            message: message,
            nick: user
        };
        //     this.socket.broadcast.emit('broadcast', 'hello friends!');
        //   this.socket.broadcast.emit('chat', payload);
    }

    public getData() {

    }
    /*
    public getMessages = () => {
        return Observable.create((observer) => {
            this.socket.on('new-message', (message) => {
                observer.next(message);
            });
        });
    }
*/

    sender: string;
    recipient: string;
    currentUser: string;

    result: string;

    messageArray: any;
    array: [];

    chatArray: ChatMessage[] = [];

    public getChatMessages(): Observable<ChatMessage[]> 
  {
      
    this.currentUser = "Name1";
    this.sender = "Name1";
    this.recipient = "name2";
    const url = 'http://localhost:5000/getChats?sender=' + this.currentUser + '&recipient=' + this.recipient;

    console.log("url:",url);
 //http://localhost:5000/getChats?sender=' + this.currentUser + '&recipient=' + this.recipient).subscribe(data => {
           
    return this.http.get<ChatMessage[]>(url);
  }


    public getInbox = () => {

        this.currentUser = "Name1";
        this.sender = "Name1";
        this.recipient = "name2";
        console.log("Get inbox...................");
        var num:number = 5; 
        var i:number; 
        var factorial = 1; 

        var counter = 0;
        this.http.get('http://localhost:5000/getChats?sender=' + this.currentUser + '&recipient=' + this.recipient).subscribe(data => {
         
            this.messageArray = data;

             counter = Object.keys(data).length;
            
             for(i = 0;i<counter;i++) {
                console.log("....",data[i]);
                this.chatArray.push(data[i]);
             }

        })






    }

}
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ChatMessage } from '../chat.model';
import { ChatService } from '../services/chat.service';
import { HttpClient } from '@angular/common/http';
import { HttpResponse } from "@angular/common/http"
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { map } from 'rxjs/operators';

export interface UserProfile {
  username: string;
  location: string;
}

@Component({
  selector: 'app-inbox-page',
  templateUrl: './inbox-page.component.html',
  styleUrls: ['./inbox-page.component.scss']
})
export class InboxPageComponent implements OnInit {

  @Output() test = new EventEmitter();

  emitTest() {
    alert("inboxPage" + this.selected);
    this.test.emit(this.selected);
  }

  constructor(private route: ActivatedRoute, private chatService: ChatService, private http: HttpClient) { }

  testVariable: string;

  @Output() userSelectedEvent = new EventEmitter<any>();

  message: string;
  user: string;
  selectedUser: string;
  private socket;

  feedback: string;
  selected: string;

  messages: ChatMessage[] = [];

  chatArray: ChatMessage[] = [];


  users: UserProfile[] = [
    { location: 'steak-0', username: 'Jane' },
    { location: 'pizza-1', username: 'Melissa' },
    { location: 'tacos-2', username: 'Tyra' }
  ];


  sendMessage() {

    console.log("User:sendMessage", this.user);
    //let chatLogs = [req.body.sender,req.body.recipient,req.body.sender_message, req.body.rec_message, rec.body.datetimechat];


    console.log("Selected", this.selectedUser);
    console.log("This message:", this.message);
    this.http.post<any>('http://localhost:5000', { sender: this.user, recipient: this.selectedUser, message: this.message }).subscribe(data => {
      this.feedback = data.id;
    })
    this.chatService.sendMessage(this.user, this.message);


    var chatItem: any = {
      chatId: "",
      sender: this.user,
      recipient: this.selectedUser,
      sender_message: this.message,
      rec_message: null,
      time: new Date
  };
    
  this.chatArray.push(chatItem);
    //   this.messages.push(this.message);
  }



  ngOnInit() {

    this.user = "Mike";

    this.route.paramMap.subscribe(params => {
      console.log("Inbox page--- ", params.get('username'))
      //  this.chatService.getContact(params.get('id')).subscribe(c =>{
      //    console.log(c);
      //    this.contact = c;
      //  })   
    });

    /*
    this.chatService
      .getMessages()
      .subscribe((message: ChatMessage) => {

        this.messages.push(message);
      });
*/
    //      this.http.get<any>('http://localhost:3000/api/car').subscribe(data => {
    //       console.log(data);
    //          this.totalAngularPackages = data.total;
    //     })

    //  this.chatService.getInbox();
    // console.log("Length,, chatarray:",this.chatService.chatArray.length);

 this.getInbox();


  }

  inbox: Observable<any[]>;

   
  getInbox() {

  //  this.chatService.getInbox();

    this.inbox = this.chatService.getChatMessages();

    let item = '';
    
    var counter = 0;
    this.inbox.forEach(elem => {

    counter++;
    var counter2 = elem.length;

    for(let j = 0; j< elem.length;j++){
     
      var chatItem: any = {
        chatId: elem[j].chatId,
        sender: elem[j].sender,
        recipient: elem[j].recipient,
        sender_message: elem[j].sender_message,
        rec_message: elem[j].rec_message,
        time: elem[j].time
    };
      
    this.chatArray.push(chatItem);


    }
  
    //  this.chatArray[0]={};
   //   { location: 'steak-0', username: 'Jane' },
      
      
    })

/*

    var i: number;
    var counter = 0;
    counter = Object.keys(this.inbox).length;
    
    console.log("Counter",counter);
    console.log("", this.inbox[1] );

    for (i = 0; i < counter; i++) {

      console.log(this.inbox[i]);
      console.log("--", JSON.stringify(this.inbox[i]));
      this.chatArray.push(this.inbox[i]);
    }

    this.chatArray.forEach(item => {
      console.log("Item::::::::::getInbox", item);
      console.log("--", JSON.stringify(item));
    })
*/

  }

}

import { Component, Input, ViewChild,Output,EventEmitter, AfterViewInit } from '@angular/core';
import { ChatService } from './services/chat.service';
import { HttpClient } from '@angular/common/http';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs';
import * as Rx from 'rxjs/Rx';
import { MatSliderModule } from '@angular/material/slider';
import { ChatMessage } from './chat.model';
import { Router, RouterModule, Routes } from '@angular/router';
import { InboxPageComponent } from './inbox-page/inbox-page.component';

export interface UserProfile {
  username: string;
  location: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit{

  testVariable:string;

  @Output() selectStory = new EventEmitter<string>();

  onSelectStory(story: string) {
    this.selectStory.emit(story);
  }

  @ViewChild( InboxPageComponent , {static: false}) userMatch: InboxPageComponent;

  @Input() quote;

  myCount: number = 10;

  ngAfterViewInit(){
  //  console.log('Hello ', this.userMatch.testVariable);
  }
  countChange(event) {
    this.myCount = event;
  }

  title = 'rxjs-chat';

  message: string;
  user: string;
  selectedValue: string; 
  private socket;

  selected:string;

  selectedCurrentUser:string;
  messages: ChatMessage[] = [];

  currentUsers: UserProfile[] = [
    {location: 'steak-0', username: 'Beth'},
    {location: 'pizza-1', username: 'Megan'},
    {location: 'tacos-2', username: 'Tina'},
    {location: 'tacos-2', username: 'Rena'},
    {location: 'tacos-2', username: 'Casy'},
    {location: 'tacos-2', username: 'Lori'}
  ]

  users: UserProfile[] = [
    {location: 'steak-0', username: 'Jane'},
    {location: 'pizza-1', username: 'Melissa'},
    {location: 'tacos-2', username: 'Tyra'},
    {location: 'tacos-2', username: 'Kate'},
    {location: 'tacos-2', username: 'Gina'},
    {location: 'tacos-2', username: 'Isa'}
  ];
  

  constructor(private router: Router,private http: HttpClient) {
    //this.connect();
  }



  connect(): Rx.Subject<MessageEvent> {
    // If you aren't familiar with environment variables then
    // you can hard code `environment.ws_url` as `http://localhost:5000`
   // this.socket = io('http://localhost:5000');
    
    // We define our observable which will observe any incoming messages
    // from our socket.io server.
    let observable = new Observable(observer => {
        this.socket.on('new-message', (data) => {
          console.log("Received message from Websocket Server",data)
          observer.next(data);
        })
        return () => {
          this.socket.disconnect();
        }
    });

    // We define our Observer which will listen to messages
    // from our other components and send messages back to our
    // socket server whenever the `next()` method is called.
    let observer = {
        next: (data: Object) => {
            this.socket.emit('new-message', JSON.stringify(data));
        },
    };

    // we return our Rx.Subject which is a combination
    // of both an observer and observable.
    return Rx.Subject.create(observer, observable);
  }

  handleTest(value) {
    alert("Selected user:" +this.selectedCurrentUser);
    alert("Selected match" + this.selected);

    this.message = this.selectedCurrentUser;
    console.log("AppComponent, Parent: ",this.message);
  }
  
  saveUser(){

    console.log("User:",this.user);
  }

  totalAngularPackages:any;


  userSelected(event){
    console.log("user selected ", this.user);
  }

  openChat(){
    console.log("Selected value, openChat",this.selected);
    console.log("Selected value, openChat",this.user);
    //this.userChange.emit("option");
   // this.router.navigate(['inboxpage']);
    this.router.navigateByUrl('inboxpage');
  }


}

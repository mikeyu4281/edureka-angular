import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { UserProfile } from '../userprofile.module';
import { ImageModel } from '../images.component';

@Component({
  selector: 'app-user-gallery',
  templateUrl: './user-gallery.component.html',
  styleUrls: ['./user-gallery.component.scss']
})
export class UserGalleryComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router) { }

     imageCount:number;
  ngOnInit() {
   this.imageCount = this.images.length;

   this.users.forEach(data=>{
     console.log(data.imgSource);
   })

   this.images.forEach(item=>{
     console.log(item);
   })
  }
  //images = [1, 2, 3].map(() => ["assets/images/amy.jpg","assets/images/rebecca.jpg","assets/images/jane.jpg"]);
 // images = [1,2,3].map(()=> {
 //   return this.getPics();
 // })
  
 // images = [1, 2, 3].map(() => `https://picsum.photos/900/500?random&t=${Math.random()}`);
  title = [ 'Slide-1','Slide-2','Slide-3','Slide-4' ];
  
  images = ["assets/images/amy.jpg","assets/images/amy.jpg","assets/images/amy.jpg"];
  

  users: ImageModel[] = [
    { imgSource: 'assets/images/amy.jpg', user: 'Jane' },
    { imgSource: 'assets/images/rebecca.jpg', user: 'Melissa' },
    { imgSource: 'assets/images/jane.jpg', user: 'Tyra' }
  ];
  /*
  images = [{ imgSource: 'assets/images/amy.jpg', user: 'Jane' },
  { imgSource: 'assets/images/rebecca.jpg', user: 'Melissa' },
  { imgSource: 'assets/images/jane.jpg', user: 'Tyra' }];
  */
  counter = 1;
  getPics(){
     let imageArray = ["assets/images/amy.jpg","assets/images/amy.jpg","assets/images/amy.jpg"];
        console.log(new Date());
      return imageArray;

  }

  moveBack(){
    this.router.navigate(['profile']).then(nav => {
      console.log(nav); // true if navigation is successful
    }, err => {
      console.log(err) // when there's an error
    });
  }

}

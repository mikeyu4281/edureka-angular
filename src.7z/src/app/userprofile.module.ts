export class UserProfile {
  
    public username: string;
    public location: string;
    public age: number;
   
   
  }
  
  
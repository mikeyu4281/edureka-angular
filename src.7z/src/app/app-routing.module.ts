import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InboxPageComponent } from '../app/inbox-page/inbox-page.component';
import { LoginComponent } from '../app/login/login.component';
import { RegisterComponent } from '../app/register/register.component';
import { ProfileComponent } from '../app/profile/profile.component';
import { UserGalleryComponent } from '../app/user-gallery/user-gallery.component';

const routes: Routes = [
  {
    path: '',
    component: InboxPageComponent,
    
},
  {
    path: 'inboxpage',
    component: InboxPageComponent,
    
},
{
  path: 'profile',
  component: ProfileComponent,
  
},
{
  path: 'login',
  component: LoginComponent,
  
},
{
  path: 'register',
  component: RegisterComponent,
  
},
{
  path:'user-gallery',
  component: UserGalleryComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

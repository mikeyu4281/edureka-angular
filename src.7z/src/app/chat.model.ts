

export class ChatMessage {
  
  public content: string;
  public subject: string;
  public from: number;
 
 
}

